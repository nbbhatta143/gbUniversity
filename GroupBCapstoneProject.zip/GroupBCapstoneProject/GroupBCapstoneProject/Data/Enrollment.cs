﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GroupBCapstoneProject.Data
{
    public class Enrollment
    {
        public int StudentID { get; set; }
        public int CourseID { get; set; }
        public DateTime Date { get; set; }
    }
}
